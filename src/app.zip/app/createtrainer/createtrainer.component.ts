import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createtrainer',
  templateUrl: './createtrainer.component.html',
  styleUrls: ['./createtrainer.component.css']
})
export class CreatetrainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

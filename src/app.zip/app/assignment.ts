import { Student } from "./student";

export class Assignment {
    aid:number;
    topic:String;
    grade:number;
    student : Student;
     
}

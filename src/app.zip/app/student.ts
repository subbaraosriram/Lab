export class Student {
    id: number;
    name: String;
     
    age: number;
    

}

import { StudentpipePipe } from './studentpipe.pipe';

describe('StudentpipePipe', () => {
  it('create an instance', () => {
    const pipe = new StudentpipePipe();
    expect(pipe).toBeTruthy();
  });
});

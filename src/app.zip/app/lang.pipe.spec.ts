import { LangPipe } from './lang.pipe';

describe('LangPipe', () => {
  it('create an instance', () => {
    const pipe = new LangPipe();
    expect(pipe).toBeTruthy();
  });
});

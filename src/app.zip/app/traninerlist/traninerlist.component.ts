import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-traninerlist',
  templateUrl: './traninerlist.component.html',
  styleUrls: ['./traninerlist.component.css']
})
export class TraninerlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

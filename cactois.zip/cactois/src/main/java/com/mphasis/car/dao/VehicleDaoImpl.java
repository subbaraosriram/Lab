/**
 * 
 */
package com.mphasis.car.dao;

/**
 * @author su.keerthanaa
 *
 */

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.car.entities.Vehicle;

@Transactional
@Repository
public class VehicleDaoImpl implements VehicleDao{

	@Autowired
	SessionFactory sessionFactory;
	
	public void insertVehicle(Vehicle vehicle) {
		try {
		Session session=sessionFactory.getCurrentSession();
		session.save(vehicle);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void updateVehicle(Vehicle vehicle) {
		try {
		Session session=sessionFactory.getCurrentSession();
		session.update(vehicle);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public Vehicle getVechicleByNo(String vno) {
		
		Session session=sessionFactory.getCurrentSession();
		Vehicle v=(Vehicle)session.get(Vehicle.class, vno);
		return v;	
		}

	public List<Vehicle> getVehicleByLocation(String location) {
		Session session=sessionFactory.getCurrentSession();
		List<Vehicle> vehicles=session.createCriteria(Vehicle.class).
				add(Restrictions.eq("current_location", location)).list();
		return vehicles;
	}
	public List<Vehicle> getVehicleByType(String type) {
		Session session=sessionFactory.getCurrentSession();
		List<Vehicle> vehicles=session.createCriteria(Vehicle.class).
				add(Restrictions.eq("vtype", type)).list();
		return vehicles;
	}


	public void deleteVehicle(String vno) {
		try {
		Session session=sessionFactory.getCurrentSession();
		Vehicle v=(Vehicle)session.get(Vehicle.class, vno);
		session.delete(v);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	public List<Vehicle> getAllVehicles() {
		Session session=sessionFactory.getCurrentSession();
		List<Vehicle> vehicles=
		session.createCriteria(Vehicle.class).list();
		return vehicles;	}


	
}

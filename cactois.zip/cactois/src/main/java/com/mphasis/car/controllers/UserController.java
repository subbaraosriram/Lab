//Bhuma Pravallika
package com.mphasis.car.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import com.mphasis.car.bo.Bookingbo;
import com.mphasis.car.bo.HelpDeskBo;
import com.mphasis.car.bo.UserBo;
import com.mphasis.car.bo.VehicleBo;
import com.mphasis.car.entities.Booking;
import com.mphasis.car.entities.HelpDesk;
import com.mphasis.car.entities.User;
import com.mphasis.car.entities.Vehicle;

@Controller
@RequestMapping(value="/user")
public class UserController {
	@Autowired
	UserBo userBo;
	@Autowired
	Bookingbo bookingbo;
	@Autowired
	HelpDeskBo helpDeskBo;
	@Autowired
	VehicleBo vehicleBo;

	@RequestMapping(value="/addcomplaint", method=RequestMethod.POST,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public void addCompplaint(@RequestBody HelpDesk helpDesk)
	{
		helpDeskBo.insertComplaint(helpDesk);
	}
	 @RequestMapping(value="/addbooking",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	  public   void addbooking(@RequestBody Booking booking)
	  {
		
		 bookingbo.addBooking(booking);
		  
	  } 
	 @RequestMapping(value="/updatebooking",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	  public    void  updatebooking(@RequestBody Booking booking)
	  {
		 Booking book =  bookingbo.getBookingById(booking.getBid());
		 if(book!=null)
		{
			bookingbo.updateBooking(book);
			 
		}
		else
		{
			bookingbo.addBooking(book);
		}
	  }
	 
	 @RequestMapping(value="/userupdate",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> updateUser(@RequestBody User user) {
	  try {
	   userBo.updateuser(user);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/userdelete/{id}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> deleteUser(@PathVariable("id") String id) {
	  try {
	   userBo.deleteuser(id);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/userlogin/{email}/{pass}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> login(@PathVariable("email") String email,@PathVariable("pass") String pass) {
	  try {
	   userBo.login(email, pass);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/userchangepassword/{oldpass}/{newpass}",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> changepassword(@PathVariable("oldpass") String oldpass,@PathVariable("newpass") String newpass) {
	  try {
	   userBo.changepassword(oldpass, newpass);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/usersignup",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> signup(@RequestBody User user) 
	 {
	  try {
	   userBo.signup(user);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/userbyid/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> getUsersById(@PathVariable("id") String id)
	 {
	  try {
	   userBo.getUsersById(id);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/userbyname/{String}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<Void> getUsersByName(@PathVariable("name") String name)
	 {
	  try {
	   userBo.getUsersByName(name);
	  }catch(Exception e) {
	   return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
	  }
	  return new ResponseEntity<Void>(HttpStatus.OK);
	 }

	 @RequestMapping(value="/vehicle/{current_location}", 
				method=RequestMethod.GET,
				produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Vehicle> getVehicleByLocation(@PathVariable("current_location")String current_location) {
			return vehicleBo.getVehicleByLocation(current_location);
		}
		
		@RequestMapping(value="/vehicle/{vtype}", 
				method=RequestMethod.GET,
				produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Vehicle> getVehicleByType(@PathVariable("vtype")String vtype) {
			return vehicleBo.getVehicleByType(vtype);
		}
		
		
		
		@RequestMapping(value="/allvehicles", method=RequestMethod.GET,
				produces=MediaType.APPLICATION_JSON_VALUE)
		public List<Vehicle> getAllVehicles()
		{
			return vehicleBo.getAllVehicles();
		}
		
	 
	 }
	 


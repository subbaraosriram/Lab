package com.mphasis.car.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity(name="cabVechile")
public class Vehicle  implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String vno;
	@Column(nullable=false)
	private String vtype;
	@Column(nullable=false)
	private String vstatus;
	@Column(nullable=false)
	private int vseats;
	@OneToOne(mappedBy="vehicle")
	private Driver driver;
	@OneToMany(mappedBy="vehicle")
	private List<Booking> booking;
	public String getVno() {
		return vno;
	}
	public void setVno(String vno) {
		this.vno = vno;
	}
	public String getVtype() {
		return vtype;
	}
	public void setVtype(String vtype) {
		this.vtype = vtype;
	}
	public String getVstatus() {
		return vstatus;
	}
	public void setVstatus(String vstatus) {
		this.vstatus = vstatus;
	}
	public int getVseats() {
		return vseats;
	}
	public void setVseats(int vseats) {
		this.vseats = vseats;
	}
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	 
	public List<Booking> getBooking() {
		return booking;
	}
	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}
	@Override
	public String toString() {
		return "Vehicle [vno=" + vno + ", vtype=" + vtype + ", vstatus=" + vstatus + ", vseats=" + vseats + ", booking="
				+ booking + "]";
	}

	
	
	

}
